Usage:
1. Right-click install.cmd -> Run as administrator (or double-click; it will prompt UAC).
2. If On-Screen Takeoff is running, close it before running the script.