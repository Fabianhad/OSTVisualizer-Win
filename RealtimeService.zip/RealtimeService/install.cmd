@echo off
setlocal

:: --- Check for admin ---
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo Requesting admin privileges...
    powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b
)

:: --- Define paths ---
set "SRCDIR=%~dp0original"
set "DLLSRC=%~dp0as2port.dll"
set "DEST=%ProgramFiles(x86)%\On-Screen Takeoff 3"

:: --- Check source exists ---
if not exist "%SRCDIR%" goto error
if not exist "%DLLSRC%" goto error

:: --- Create destination ---
if not exist "%DEST%" mkdir "%DEST%"

:: --- Copy the folder itself ---
robocopy "%SRCDIR%" "%DEST%\original" /E /R:1 /W:1 >nul

:: --- Copy the DLL ---
copy /Y "%DLLSRC%" "%DEST%\as2port.dll" >nul

echo Installation complete!
timeout /t 3 /nobreak >nul
exit /b 0

:error
echo Installation failed. Please check the source files.
timeout /t 5 >nul
exit /b 1
